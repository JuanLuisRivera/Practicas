public class Cuenta {
    private String titular;
    private double dineroDisponible;

    public Cuenta(String titular){
      this.titular = titular;
      this.dineroDisponible = 0.0;
    }

    public Cuenta(){
      this.titular = "Rivera Ibarra Juan Luis";
      this.dineroDisponible = 10.0;
    }


    public String gettitular(){
      return titular;
    }

    public double getdineroDisponible(){
      return dineroDisponible;
    }

    public void settitular(String titular){
      this.titular = titular;
    }

    public void setdineroDisponible(double dineroDisponible){
      this.dineroDisponible = dineroDisponible;
    }

    public String toString(){
      return ("Tienes una cuenta cuyo dinero disponible es: " + getdineroDisponible() + ", " + gettitular());
    }

}
