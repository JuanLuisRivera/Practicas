public class Rectangulo {
    private double base;
    private double altura;

    public Rectangulo(double base, double altura){
      this.base = base;
      this.altura = altura;
    }

    public Rectangulo(){
      this.base = 10.0;
      this.altura = 10.0;
    }


    public double getbase(){
      return base;
    }

    public double getaltura(){
      return altura;
    }

    public void setbase(double base){
      this.base = base;
    }

    public void setaltura(double altura){
      this.altura = altura;
    }

    public double arearectangulo(double base, double altura){
      double arearectangulo = base*altura;
      return arearectangulo;
    }

    public double perimetrorectangulo(double base, double altura){
      double perimetrorectangulo = 2 * base + 2 * altura;
      return perimetrorectangulo;
    }

    public String toString(){
      return ("Tienes un rectangulo cuya area es: " + arearectangulo(base, altura) + " y un perimetro: " + perimetrorectangulo(base, altura));
    }

}
