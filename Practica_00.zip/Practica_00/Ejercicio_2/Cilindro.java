class Cilindro{
  public static void main(String[] args){
    int radio = 10;
    int altura = 20;
    double pi = 3.1415;
    double area;
    double volumen;

    System.out.print("El area del cilindro es: " + (2 * pi * radio * altura + 2 * pi * (radio * radio)) + "cm² \n");
    System.out.print("El volumen del cilindro es: " + (pi * radio * radio * altura) + "cm³ \n");
  }
}
