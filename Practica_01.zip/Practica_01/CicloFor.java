class CicloFor{
  public static void main(String[] args){
    for (int i = 2; i <= 1000 ; i ++) {
      boolean esprimo = true;
      for (int j = 2; j < i ; j ++ ) {
        if (i % j == 0) {
          esprimo = false;
        }
      }
      if (esprimo) {
        System.out.println(i);
      }
    }
  }
}
