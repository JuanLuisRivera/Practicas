import java.util.Scanner;

class Bisiesto{
  public static void main(String[] args){
    Scanner input = new Scanner(System.in);

    System.out.print("Ingresa un año: \n");
    int m = input.nextInt();

    if (m % 400 == 0){
      System.out.println("Es bisiesto.");
    }
    if(m % 4 == 0){
      if(! (m % 100 == 0)){
        System.out.println("Es bisiesto.");
      }
    }
    else{
      System.out.println("No es bisisesto.");
    }

    input.close();
  }
}
