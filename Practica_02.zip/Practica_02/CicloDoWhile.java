class CicloDoWhile{
  public static void main(String[] args){
    int i = 2;
    do {
      boolean esprimo = true;
      int j = 2;
      do {
        if (i % j == 0 && i != 2) {
          esprimo = false;
        }
        j++;
      } while (j < i);
      if (esprimo) {
        System.out.println(i);
      }
      i++;
    } while (i != 1000);
  }
}
