class CicloWhile{

  public static void main(String[] args){
    int i = 2;
    while (i < 1000){
      boolean esprimo = true;
      int j = 2;
      while (j < i) {
        if (i % j == 0) {
          esprimo = false;
        }
        j++;
      }
      if (esprimo) {
        System.out.println(i);
      }
      i++;
    }
  }
}
